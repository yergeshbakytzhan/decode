function openModal(){
    document.getElementById("modal").classList.add("active")
}
function closeModal(){
    document.getElementById("modal").classList.remove("active")
}